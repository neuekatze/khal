| Stem 1: | Stem 2: | Stem 3: | **A**       |
| ------- | ------- | ------- | ----------- |
| sl 1    | sl 6    | sl 11   | Basic       |
| sl 2    | sl 7    | sl 12   | Content     |
| sl 3    | sl 8    | sl 13   | Constitutor |
| sl 4    | sl 9    | sl 14   | Object      |
| sl 5    | sl 10   | sl 15   | Person      |

| Stem 1: | Stem 2: | Stem 3: | Stem 4: | Stem 5: | Stem 6: | **A6**       |
| ------- | ------- | ------- | ------- | ------- | ------- | ----------- |
| sl 1    | sl 6    | sl 11   | sl 16   | sl 21   | sl 26   | Basic       |
| sl 2    | sl 7    | sl 12   | sl 17   | sl 22   | sl 27   | Content     |
| sl 3    | sl 8    | sl 13   | sl 18   | sl 23   | sl 28   | Constitutor |
| sl 4    | sl 9    | sl 14   | sl 19   | sl 24   | sl 29   | Object      |
| sl 5    | sl 10   | sl 15   | sl 20   | sl 25   | sl 30   | Person      |


|N  |
|---|
|Definition of sl 1 to 73 goes here.|