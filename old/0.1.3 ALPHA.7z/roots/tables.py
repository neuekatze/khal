from re import split, compile
import os
    
templ = input(": ")
pattern = compile("\n|,")
file = r"C:\Users\qazw\Desktop\khal\roots\temp\\" + "root"+ templ + ".csv"
tempo = r"C:\Users\qazw\Desktop\khal\roots\temp\temporary.md"
with open(file) as f:
    s = f.read()
    print(os.system('csv2md '+file))
    table = pattern.split(s)

dictionary = dict(zip(table, list(range(len(table)))))
print(dictionary)
for i in range(1, len(table)):
    os.system('cls')
    print(i, "\n\n")
    print(table)
    x = input(": ")
    if x == "q":
        break
    table[dictionary["sl "+str(i)]] = x
    print(table)