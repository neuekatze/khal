| description | conjunction |
| ----------- | ----------- |
| ǫ̈       | ę̈       |
