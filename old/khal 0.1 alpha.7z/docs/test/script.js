function createTable() {
    // Get the number of rows and columns from the inputs
    const rows = document.getElementById('rows').value;
    const columns = document.getElementById('columns').value;

    // Get the table container
    const tableContainer = document.getElementById('table-container');

    // Clear the previous table
    tableContainer.innerHTML = '';

    // Create a new table
    const table = document.createElement('table');

    // Create the table header
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    for (let c = 0; c < columns; c++) {
        const th = document.createElement('th');
        th.textContent = `Header ${c + 1}`;
        headerRow.appendChild(th);
    }
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Create the table body
    const tbody = document.createElement('tbody');
    for (let r = 0; r < rows; r++) {
        const row = document.createElement('tr');
        for (let c = 0; c < columns; c++) {
            const td = document.createElement('td');
            td.innerHTML = `<input type="text" placeholder="Row ${r + 1}, Col ${c + 1}">`;
            row.appendChild(td);
        }
        tbody.appendChild(row);
    }
    table.appendChild(tbody);

    // Append the table to the container
    tableContainer.appendChild(table);
}
