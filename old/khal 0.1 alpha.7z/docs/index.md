# Welcome to kʰa
Kʰa is a language. Lorem ipsum dolor sit amet. 𐰇𐰔𐰀 : 𐰴𐰍𐰣 : 𐰆𐰞𐰺𐱃𐰢 : 𐰆𐰞𐰺𐱃𐰸𐰢𐰀 : 𐰇𐰠𐱅𐰲𐰃𐰲𐰀 : 𐰽𐰴𐰣𐰍𐰢𐰀 : 𐱅𐰇𐰼𐰜 : 𐰋𐰏𐰠𐰼 : 𐰉𐰆𐰑𐰣 : 𐰏𐰼𐰯 : 𐰾𐰋𐰤𐰯 : 𐱃𐰆𐰭𐱃𐰢𐱁 :

