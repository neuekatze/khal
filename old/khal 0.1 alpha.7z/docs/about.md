<table>
    <tr>
        <th>Labial</th>
        <td>Dental</td>
        <td>Alveolar</td>
        <td></td>
        <td>Retroflex</td>
        <td></td>
        <td>Palatal</td>
        <td>Velar</td>
        <td>Uvular</td>
        <td>Pharyngeal</td>
        <td>Glottal</td>
    </tr>
    <tr>
        <th></th>
        <td></td>
        <td></td>
        <td></td>
        <td>central</td>
        <td>lateral</td>
        <td>Post-alveolar</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th>Nasal</th>
        <td></td>
        <td>m</td>
        <td>n̪ ⟨n⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>ɲ ⟨ñ⟩</td>
        <td>ŋ ⟨ň⟩</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>palatal</td>
        <td>mʲ ⟨m̂⟩</td>
        <td>n̪ʲ ⟨n̂/nʸ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th>Plosive</th>
        <td>voiced</td>
        <td>b</td>
        <td>d̪ ⟨d⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>ɟ ⟨ĝ⟩</td>
        <td>ɡ</td>
        <td>ɢ ⟨ġ⟩</td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>voiceless</td>
        <td>p</td>
        <td>t̪ ⟨t⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>c ⟨ķ⟩</td>
        <td>k</td>
        <td>q</td>
        <td></td>
        <td>ʔ ⟨’⟩</td>
    </tr>
    <tr>
        <th></th>
        <td>aspirated</td>
        <td>pʰ ⟨p̬/pʰ⟩</td>
        <td>t̪ʰ ⟨t̬/tʰ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>cʰ ⟨k̝/kʰ⟩</td>
        <td>kʰ ⟨k̬/kʰ⟩</td>
        <td>qʰ ⟨q̬/qʰ⟩</td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>ejective</td>
        <td>pʼ</td>
        <td>t̪ʼ ⟨tʼ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>cʼ ⟨ķʼ⟩</td>
        <td>kʼ</td>
        <td>qʼ</td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>vl palatal</td>
        <td>pʲ ⟨p̂/pʸ⟩</td>
        <td>tʲ ⟨t̂/tʸ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>v. palatal</td>
        <td>bʲ ⟨b̂/bʸ⟩</td>
        <td>dʲ ⟨d̂/dʸ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th>Affricate</th>
        <td>voiced</td>
        <td></td>
        <td></td>
        <td>dz ⟨ƶ⟩</td>
        <td></td>
        <td>ɖʐ ⟨ż⟩</td>
        <td>dʒ ⟨j⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>voiceless</td>
        <td></td>
        <td></td>
        <td>ts ⟨c⟩</td>
        <td></td>
        <td>ʈʂ ⟨ċ⟩</td>
        <td>tʃ ⟨č⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>v. palatal</td>
        <td></td>
        <td></td>
        <td>dzʲ ⟨ƶ/ʸ⟩</td>
        <td></td>
        <td>ɖʐʲ ⟨ż̂/żʸ⟩</td>
        <td>dʒʲ ⟨ĵ/jʸ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>vl palatal</td>
        <td></td>
        <td></td>
        <td>tsʲ ⟨ĉ/cʸ⟩</td>
        <td></td>
        <td>ʈʂʲ ⟨ċ̂/ċʸ⟩</td>
        <td>tʃʲ ⟨čʸ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>aspirated</td>
        <td></td>
        <td></td>
        <td>tsʰ ⟨c̬/cʰ⟩</td>
        <td>cʎ̥˔ʰ ⟨q̌⟩</td>
        <td>ʈʂʰ ⟨ċ̬/ċʰ⟩</td>
        <td>tʃʰ ⟨č̬/čʰ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>ejective</td>
        <td></td>
        <td></td>
        <td>tsʼ ⟨c’⟩</td>
        <td></td>
        <td>ʈʂʼ ⟨ċʼ⟩</td>
        <td>tʃʼ ⟨č’⟩</td>
        <td>cçʼ ⟨çʼ⟩</td>
        <td>kxʼ ⟨xʼ⟩</td>
        <td>qχʼ ⟨χʼ⟩</td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th>Fricative</th>
        <td>voiced</td>
        <td>v</td>
        <td>ð ⟨đ⟩</td>
        <td>z</td>
        <td>ɮ ⟨l̊⟩</td>
        <td>ʐ ⟨z̧⟩</td>
        <td>ʒ ⟨ž⟩</td>
        <td>ʝ ⟨y̌⟩</td>
        <td>ɣ ⟨ǧ/γ⟩</td>
        <td></td>
        <td>(ʕ ⟨´⟩)</td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>voiceless</td>
        <td>f</td>
        <td>θ ⟨ţ⟩</td>
        <td>s</td>
        <td>ɬ ⟨ļ⟩</td>
        <td>ʂ ⟨ş⟩</td>
        <td>ʃ ⟨š⟩</td>
        <td>ç</td>
        <td>x</td>
        <td>χ</td>
        <td>ħ ⟨ḩ⟩</td>
        <td>h</td>
    </tr>
    <tr>
        <th></th>
        <td>v palatal</td>
        <td>vʲ ⟨v̂/vʸ⟩</td>
        <td>ðʲ ⟨đ̂/đʸ⟩</td>
        <td>zʲ ⟨ẑ/zʸ⟩</td>
        <td></td>
        <td>ʐʲ ⟨ẑ̧/z̧ʸ⟩</td>
        <td>ʒʲ ⟨žʸ⟩</td>
        <td></td>
        <td>ɣʲ ⟨ğʸ/γ̂/γʸ⟩</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>vl palatal</td>
        <td>fʲ ⟨f̂/fʸ⟩</td>
        <td>θʲ ⟨ţ̂/ţʸ⟩</td>
        <td>sʲ ⟨ŝ/sʸ⟩</td>
        <td>ɬʲ ⟨ļʸ⟩</td>
        <td>ʂʲ ⟨ş̂/şʸ⟩</td>
        <td>ʃʲ ⟨šʸ⟩</td>
        <td></td>
        <td>xʲ ⟨x̂/xʸ⟩</td>
        <td>χʲ ⟨χ̂/χʸ⟩</td>
        <td>ħʲ ⟨ḩ̂/ḩʸ⟩</td>
        <td>hʲ ⟨ĥ/hʸ⟩</td>
    </tr>
    <tr>
        <th>Liquid</th>
        <td>flap</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>ɽ ⟨r⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td>non-flap</td>
        <td></td>
        <td></td>
        <td></td>
        <td>l̪ ⟨l⟩</td>
        <td>ɻ ⟨ŗ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th></th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>l̪ʲ ⟨l̂/lʲ⟩</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th>Approximant</th>
        <td></td>
        <td>w</td>
        <td></td>
        <td></td>
        <td>ɫ̪ ⟨ł⟩</td>
        <td></td>
        <td></td>
        <td>j ⟨y⟩</td>
        <td></td>
        <td>ʁ̞ ⟨ř⟩</td>
    </tr>
</table>